import 'package:flutter/material.dart';

class Subject {
  final String name;
  late final int creditHours;

  Subject(this.name, this.creditHours);
}

class SubjectInput extends StatefulWidget {
  final Function(Subject) onSubjectAdded;

  const SubjectInput({super.key, required this.onSubjectAdded});

  @override
  State<SubjectInput> createState() => _SubjectInputState();
}

class _SubjectInputState extends State<SubjectInput> {
  final _nameController = TextEditingController();
  final _creditHoursController = TextEditingController();

  void _addSubject() {
    final name = _nameController.text;
    final creditHours = int.tryParse(_creditHoursController.text) ?? 0; // Handle invalid input
    if (name.isNotEmpty) {
      widget.onSubjectAdded(Subject(name, creditHours));
      _nameController.clear();
      _creditHoursController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: 'Subject Name'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: _creditHoursController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Credit Hours'),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.add),
          onPressed: _addSubject,
        ),
      ],
    );
  }
}

List<List<List<TimetableEntry>>> generateTimetable(List<Subject> subjects) {
  final predefinedRooms = [
    'Room A',
    'Room B',
    'Room C',
    // ... Add more rooms as needed
  ];

  // Timetable ko initialize karte hain taake har slot mein multiple subjects ki support ho
  final timetable = List.generate(
    5, // Dinon ki tadaad (Monday to Friday)
        (_) => List.generate(
      9, // Slots ki tadaad (har din mein 9 slots)
          (_) => <TimetableEntry>[], // Har slot mein TimetableEntry ki list
    ),
  );

  // Har subject ko time slots mein distribute karte hain
  for (final subject in subjects) {
    for (int day = 0; day < 5; day++) {
      int slot = 0;

      while (slot < 9 && subject.creditHours > 0) {
        // Yeh check karta hai ke slot already full hai ya nahi
        if (timetable[day][slot].length < 2) { // Aap maximum subjects ki limit yahan set kar sakte hain
          timetable[day][slot].add(
            TimetableEntry(
              subject: subject,
              room: predefinedRooms[slot % predefinedRooms.length],
            ),
          );
          subject.creditHours--;
        }
        slot++;
      }
    }
  }

  return timetable;
}

class TimetableEntry {
  final Subject? subject;
  final String room;

  TimetableEntry({this.subject, this.room = ''});
}

class TimetableScreen extends StatelessWidget {
  final List<List<List<TimetableEntry>>> timetable;

  const TimetableScreen({super.key, required this.timetable});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Timetable'),
        actions: [
          IconButton(icon: const Icon(Icons.download), onPressed: () {
            // _downloadTimetable(context); // Function to download PDF
          }),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Text('Timetable', style: TextStyle(fontSize: 20)),
            Table(
              border: TableBorder.all(color: Colors.grey),
              children: [
                TableRow(
                  children: [
                    const TableCell(child: Text('Day')),
                    ...List.generate(9, (index) => Text(getTimeSlot(index))),
                  ],
                ),
                ...List.generate(5, (dayIndex) => _buildTimetableRow(dayIndex)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String getTimeSlot(int index) {
    final startTime = Duration(hours: 8, minutes: 30 + index * 30);
    final endTime = startTime + const Duration(minutes: 30);
    return '${startTime.toString().substring(11, 16)} - ${endTime.toString().substring(11, 16)}';
  }

  TableRow _buildTimetableRow(int dayIndex) {
    return TableRow(
      children: [
        TableCell(
          verticalAlignment: TableCellVerticalAlignment.middle,
          child: Text(weekdays[dayIndex]),
        ),
        ...List.generate(
          9,
              (slotIndex) => _buildTimetableEntries(timetable[dayIndex][slotIndex]),
        ),
      ],
    );
  }

  Widget _buildTimetableEntries(List<TimetableEntry> entries) {
    if (entries.isNotEmpty) {
      return TableCell(
        verticalAlignment: TableCellVerticalAlignment.middle,
        child: Column(
          children: [
            Divider(), // Top divider
            ...entries.asMap().entries.map((entry) {
              final timetableEntry = entry.value;
              final index = entry.key;
              return Column(
                children: [
                  Text(timetableEntry.subject?.name ?? ''),
                  Text('(${timetableEntry.subject?.creditHours} CH)'),
                  Text(timetableEntry.room),
                  Divider(), // Bottom divider after each subject
                ],
              );
            }).toList(),
          ],
        ),
      );
    } else {
      return const TableCell(child: Text(''));
    }
  }

  final weekdays = const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
}
