import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:npp/Aboutuspage.dart';
import 'package:npp/helpscreen.dart';
import 'package:npp/signin.dart';
import 'package:npp/splshScreen.dart';
import 'package:pdf/pdf.dart';
import 'dart:math';
import 'package:pdf/widgets.dart' as pw;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';

import 'firebase_options.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

List<String> _timeSlots = [
  '4:00PM-5:00PM',
  '3:00PM-4:00PM',
  '2:00PM-3:00PM',
  '1PM-2PM',
  '12:15PM-1:00PM',
  '11:30AM-12:15PM',
  '10:30AM-11:30AM',
  '9:30AM-10:30AM',
  '8:30AM-9:30AM',
];

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Generator',
      home: SplashScreen(),
    );
  }
}

class TimetableGenerator extends StatefulWidget {
  const TimetableGenerator({super.key});

  @override
  _TimetableGeneratorState createState() => _TimetableGeneratorState();
}

class _TimetableGeneratorState extends State<TimetableGenerator> {
  int _subjectCount = 0;
  final List<Subject> _subjects = [];
  final List<String> _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  final List<String> _rooms = [
    'DB-001',
    'DB-002',
    'DB-003',
    'DB-004',
    'DB-005',
    'DB-006',
    'DB-007',
    'DB-008',
    'C-201',
    'C-202',
    'CB-002',
    'JB-005',
    'JB-006',
    'JB-007',
    'JB-008',
    'G-201',
    'G-202',
    'GG-002',

  ]; // Initialize as empty

  final List<String> _teachers = [
    'Dr. Sadaf Tanvir',
    'Dr. Mukhtar Qureshi',
    'Mr. Hafiz M.Murtaza',
    'Ms. Aqsa Ashfaq',
    'Mr. Jasim Ali',
    'Ms. Faiza Habib',
    'Dr. Amjad Khan',
    'Mr. Abdul Hannan',
    'Ms. Aroosa Yaqoob',

  ];
// Define subject-teacher mapping
  final Map<String, List<String>> teacherSubjects = {
    'Dr.M.Yousaf Khan': ['CC', 'TOA', 'Civic and Community Engagement'],
    'Dr. Sadaf Tanvir': ['ITP', 'DPC', 'Artificial Intelligence', 'ITC'],
    'Mr. Abdul Basit': ['R & M', 'NC', 'English 3'],
    'Dr. Mukhtar Qureshi': ['Physics', 'DPC', 'ITP', 'Artificial Intelligence'],
    'Mr. Hafiz M.Murtaza': ['ITC', 'Physics', 'CN'],
    'Ms. Madiha Hena': ['Discrete Structures', 'Statistics and Probability', 'Linear Algebra', 'NC'],
    'Dr. Amjad Khan': ['Artificial Intelligence', 'DBMS'],
    'Mr. Shahzaib Iqbal': ['Linear Algebra', 'DIP', 'Data Warehousing'],
    'Ms. Aqsa Ashfaq': ['COAL', 'AOA', 'MPL', 'OOP'],
    'Ms. Naveen Ahmed': ['Information Security', 'Entrepreneurship', 'Data Warehousing'],
    'Mr. Abdul Hannan': ['Computer Architecture', 'ITP', 'ITC'],
    'Ms. Aroosa Yaqoob': ['DSA', 'DBMS', 'OOP', 'AOA'],
    'Ms. Faiza Habib': ['Computer Networks', 'Advance DBMS', 'HCI'],
    'Ms. Ayesha Amjid': ['Web Security', 'WPL', 'Linear Algebra', 'Computer Vision'],
    // More teachers add here
  };


  int? hour;
  Timetable1? _bestTimetable;

  @override
  void initState() {
    super.initState();
  }

  final _labformKey = GlobalKey<FormState>();
  final _formKey = GlobalKey<FormState>();
  final List<GlobalKey<FormState>> _subjectFormKeys = [];
  final _subjectCountController = TextEditingController();
  final labController = TextEditingController();
  final labnameController = TextEditingController();
  final List<TextEditingController> _subjectNameControllers = [];
  final List<TextEditingController> _creditHoursControllers = [];
  final _roomsController = TextEditingController(); // For room input
  final _teachersController = TextEditingController(); // For teacher input
  final _advancedDrawerController = AdvancedDrawerController();
  bool isloading = false;
  Subject? findSubject(Timetable1? timetable, String timeSlot, String day) {
    if (timetable == null) {
      return null; // Handle case where timetable is not yet generated
    }

    int dayIndex = _days.indexOf(day);
    int timeIndex = _timeSlots.indexOf(timeSlot);
    return timetable.schedule[timeIndex][dayIndex];
  }


  @override
  void dispose() {
    // Dispose of controllers to avoid memory leaks
    _subjectCountController.dispose();
    for (var controller in _subjectNameControllers) {
      controller.dispose();
    }
    for (var controller in _creditHoursControllers) {
      controller.dispose();
    }
    _roomsController.dispose();
    _teachersController.dispose();
    super.dispose();
  }


  Widget _buildTimetableGrid() {
    return SingleChildScrollView(
      // Allow scrolling if timetable is long
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: DataTable(
          dataRowHeight: 150,
          columnSpacing: 10,
          horizontalMargin: 20,
          columns: [
            const DataColumn(
                label:
                    SizedBox(width: 150, child: Text('Time'))), // Time column
            ..._days.map((day) => DataColumn(label: Text(day))), // Day headers
          ],
          rows: _timeSlots.reversed.toList().asMap().entries.map((entry) {
            int timeIndex = entry.key;
            String timeSlot = entry.value;

            return DataRow(cells: [
              DataCell(Text(timeSlot)), // Time slot cell
              ..._days.map((day) {
                Subject? subject = findSubject(_bestTimetable, timeSlot, day);
                bool isBreakTime = timeSlot == '1PM-2PM';

                return DataCell(
                  subject != null
                      ? Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey[300]!),
                            color: subject.name != 'Free time'
                                ? isBreakTime
                                    ? Colors.green
                                    : Colors.primaries[Random()
                                            .nextInt(Colors.primaries.length)]
                                        .withOpacity(0.3)
                                : null,
                          ),
                          width: 150,
                          child: isBreakTime
                              ? const Text('Break Time')
                              : Center(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(subject.name), // Subject name
                                      if (subject.room != null)
                                        Text(subject.room!), // Room
                                      if (subject.teacher != null)
                                        Text(subject.teacher!), // Teacher
                                    ],
                                  ),
                                ),
                        )
                      : Container(), // Empty cell if no subject
                );
              }).toList(),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  void _showDownloadOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: const Text('Download as PDF'),
                onTap: _downloadAsPdf,
              ),

            ],
          ),
        );
      },
    );
  }


  Future<void> _downloadAsPdf() async {
    if (await Permission.storage.request().isGranted) {
      final pdf = pw.Document();
      final pageFormat = PdfPageFormat.a4;
      pdf.addPage(
        pw.MultiPage(
          pageFormat: pageFormat,
          build: (pw.Context context) {
            return [
              pw.Table(
                border: pw.TableBorder.all(width: 1),
                columnWidths: {0: pw.FixedColumnWidth(175)},
                children: [
                  pw.TableRow(
                    children: [
                      pw.Container(width: 175, child: pw.Text('Time')),
                      ..._days.map((day) => pw.Expanded(child: pw.Center(child: pw.Text(day)))),
                    ],
                  ),
                  ..._timeSlots.reversed.map((timeSlot) {
                    return pw.TableRow(
                      children: [
                        pw.Container(width: 175, child: pw.Text(timeSlot)),
                        ..._days.map((day) {
                          Subject? subject = findSubject(_bestTimetable, timeSlot, day);
                          bool isBreakTime = timeSlot == '1PM-2PM';

                          return pw.Expanded(
                            child: pw.Container(
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.grey300),
                                color: isBreakTime
                                    ? PdfColors.green200
                                    : subject != null ? PdfColors.white : null,
                              ),
                              padding: const pw.EdgeInsets.all(8),
                              child: isBreakTime
                                  ? pw.Center(child: pw.Text('Break Time'))
                                  : subject != null
                                  ? pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                                  pw.Text(subject.name),
                                  if (subject.room != null)
                                    pw.Text(subject.room!),
                                  if (subject.teacher != null)
                                    pw.Text(subject.teacher!),
                                ],
                              )
                                  : pw.Container(),
                            ),
                          );
                        }).toList(),
                      ],
                    );
                  }).toList(),
                ],
              ),
            ];
          },
        ),
      );

      try {
        final output = await getTemporaryDirectory();
        print("PDF will be saved at: ${output.path}");  // Debug line
        final file = File('${output.path}/TimeTable.pdf');
        await file.writeAsBytes(await pdf.save());
        print("PDF file created successfully.");  // Debug line

        final params = SaveFileDialogParams(
            sourceFilePath: file.path, fileName: 'TimeTable.pdf');
        await FlutterFileDialog.saveFile(params: params);
      } catch (e) {
        print("Error during PDF download: $e");  // Debug line
      }
    } else {
      print("Permission denied");  // Debug line
    }
  }



/////////////////////////DRAWER///////////////////////
  @override
  Widget build(BuildContext context) {
    void _handleMenuButtonPressed() {
      _advancedDrawerController.toggleDrawer(); // This will toggle the drawer
    }

    return AdvancedDrawer(
      backdrop: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.green, Colors.lightGreen.withOpacity(0.2)],
          ),
        ),
      ),
      controller: _advancedDrawerController,
      animationCurve: Curves.easeInOut,
      animationDuration: const Duration(milliseconds: 300),
      animateChildDecoration: true,
      rtlOpening: false,
      disabledGestures: false,
      childDecoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
      drawer: SafeArea(
        child: Container(
          child: ListTileTheme(
            textColor: Colors.black,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: 158.0,
                  height: 158.0,
                  margin: const EdgeInsets.only(
                    top: 30.0,
                    bottom: 40.0,
                  ),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.green, width: 7.0),
                  ),
                  child: ClipOval(
                    child: Image.asset('images/SMT.jpeg', fit: BoxFit.cover),
                  ),
                ),
                ListTile(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TimetableGenerator()),
                    );
                  },
                  leading: const Icon(Icons.home, color: Colors.green),
                  title: const Text('Home', style: TextStyle(color: Colors.black)),
                ),
                const Divider(
                  color: Colors.black,
                  thickness: 1.0,
                  height: 20.0,
                  indent: 16.0,
                  endIndent: 16.0,
                ),
                ListTile(
                  onTap: () {
                    Get.to(() => const HelpScreen());
                  },
                  leading: const Icon(Icons.account_circle_rounded, color: Colors.blue),
                  title: const Text('Help', style: TextStyle(color: Colors.black)),
                ),
                const Divider(
                  color: Colors.black,
                  thickness: 1.0,
                  height: 20.0,
                  indent: 16.0,
                  endIndent: 16.0,
                ),
                ListTile(
                  onTap: () {
                    Get.to(() => const AboutUsPage());
                  },
                  leading: const Icon(Icons.favorite, color: Colors.black),
                  title: const Text('About', style: TextStyle(color: Colors.black)),
                ),
                const Divider(
                  color: Colors.black,
                  thickness: 1.0,
                  height: 20.0,
                  indent: 20.0,
                  endIndent: 10.0,
                ),
                ListTile(
                  onTap: () {
                    var auth = FirebaseAuth.instance;
                    auth.signOut().then((value) {
                      Get.offAll(() => const LoginPage());
                    });
                  },
                  leading: const Icon(Icons.logout, color: Colors.red),
                  title: const Text('Logout', style: TextStyle(color: Colors.black)),
                ),
                const Spacer(),
                DefaultTextStyle(
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white54,
                  ),
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 16.0),
                    child: const Text(
                      'Terms of Service || Privacy Policy',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: _handleMenuButtonPressed,
            icon: ValueListenableBuilder<AdvancedDrawerValue>(
              valueListenable: _advancedDrawerController,
              builder: (_, value, __) {
                return AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Icon(
                    value.visible ? Icons.clear : Icons.menu,
                    key: ValueKey<bool>(value.visible),
                  ),
                );
              },
            ),
          ),
          title: const Text('Generator'),
          actions: [
            if (_bestTimetable != null)
              IconButton(
                icon: const Icon(Icons.download),
                onPressed: () => _downloadAsPdf(),
              ),
            if (_bestTimetable != null)
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () {
                  // Your existing dialog code
                  AlertDialog alert = AlertDialog(
                    title: const Text("Lab Hours"),
                    content: Form(
                      key: _labformKey,
                      child: SizedBox(
                        child: Column(
                          children: [
                            TextFormField(
                              controller: labnameController,
                              keyboardType: TextInputType.text,
                              decoration: const InputDecoration(
                                labelText: 'Enter Subject name',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a name';
                                }
                                if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
                                  return 'Please enter only letters';
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    actions: [
                      TextButton(
                        child: const Text("Cancel"),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                      TextButton(
                        child: const Text("Continue"),
                        onPressed: () {
                          if (_labformKey.currentState?.validate() ?? false) {
                            setState(() {
                              addLab(_bestTimetable!, labnameController!.text);
                            });
                            Navigator.pop(context);
                          }
                        },
                      ),
                    ],
                  );

                  // Show the dialog
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return alert;
                    },
                  );
                },
              ),
          ],
        ),



        ////////////////////DRAWER end////////////////////
        body: SingleChildScrollView(
          child: Column(children: [
            if (_bestTimetable != null) _buildTimetableGrid(),
            if (_bestTimetable == null) ...[
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _subjectCountController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Number of Subjects'),
                      validator: (value) {
                        int? count = int.tryParse(value!);
                        if (count == null || value.isEmpty) {
                          return 'Please enter a number';
                        } else if (count >= 54 || count <= 4) {
                          return 'Please enter a valid number greater than 5 less than 55';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        if (_formKey.currentState!.validate()) {
                          _updateSubjectInputFields();
                        }
                      },
                    ),
                    const SizedBox(height: 15),
                    Builder(builder: (context) {
                      if (_subjectCount == 0) {
                        return Container();
                      }
                      return SizedBox(
                        height: 400,
                        child: ListView(
                          children: List.generate(_subjectCount, (index) {
                            final subjectFormKey = _subjectFormKeys[index];
                            return _subjectInputRow(index + 1, subjectFormKey);
                          }),
                        ),
                      );
                    }),
                  ],
                ),
              ),
              SizedBox(
                height: 50,
                width: 140,
                child: ElevatedButton(
                  onPressed: () async {
                    // Check if _formKey's current state is not null
                    if (_formKey.currentState?.validate() == true &&
                        _subjectFormKeys.every((key) => key.currentState?.validate() == true)) {
                      setState(() {
                        isloading = !isloading;
                      });
                      _collectSubjectData();
                      _bestTimetable = await generateTimetables(_subjects);
                      setState(() {
                        adjustSubjectOccurrences(_bestTimetable, _subjects);
                        for (int i = 0; i < _timeSlots.length; i++) {
                          String day = _timeSlots[i];
                          List<Subject?> subjects = _bestTimetable!.schedule[i];
                          print(
                              "$day: ${subjects.map((s) => s?.name ?? 'Free').join(', ')}");
                        }
                      });
                    }
                  },

                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                    elevation: MaterialStateProperty.all<double>(10),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                  ),
                  child: isloading
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(),
                  )
                      : const Text('Generate', style: TextStyle(color: Colors.black)),
                ),
              ),
            ]
          ]),
        ),
      ),
    );
  }


//Adjust Subject Occurrences in Best Timetable
  Timetable1 adjustSubjectOccurrences(
      Timetable1? bestTimetable, List<Subject> subjects) {
    if (bestTimetable == null) {
      throw ArgumentError("Best timetable cannot be null.");
    }
    // Define a dummy subject
    final dummySubject =
        Subject(name: "Free time", creditHours: 0, room: '', teacher: '');
    // Count subject occurrences in the best timetable
    final subjectCounts = <Subject, int>{};
    for (var day in bestTimetable.schedule) {
      for (var subject in day) {
        if (subject != null && subject != dummySubject) {
          subjectCounts[subject] = (subjectCounts[subject] ?? 0) + 1;
        }
      }
    }
    // Replace excess occurrences with the dummy subject
    for (var subject in subjects) {
      int occurrences = subjectCounts[subject] ?? 0;
      if (occurrences > subject.creditHours) {
        for (var day in bestTimetable.schedule) {
          for (int i = 0; i < day.length; i++) {
            if (day[i] == subject) {
              day[i] = dummySubject;
              occurrences--;
              if (occurrences == subject.creditHours) break;
            }
          }
          if (occurrences == subject.creditHours) break;
        }
      }
    }

    return bestTimetable; // Return the modified timetable
  }



  /// LAB SLOTS //////////////3 credit hours
  Timetable1 addLab(Timetable1 bestTimetable, String name) {
    final dummySubject = Subject(name: "Free time", creditHours: 0, room: '', teacher: '');

    // Get a list of teachers available for the lab subject
    List<String> availableTeachers = teacherSubjects.entries
        .where((entry) => entry.value.contains(name)) // Check if teacher teaches the lab subject
        .map((entry) => entry.key)
        .toList();

    // Select a random teacher from the list of available teachers
    final random = Random();
    String teacher = availableTeachers.isNotEmpty ? availableTeachers[random.nextInt(availableTeachers.length)] : ''; // Select a random teacher if available

    // Create lab subject and time slot
    final labSubject = Subject(name: "$name (Lab Time)", creditHours: 3, room: '', teacher: teacher);
    final labTimeSlot = Subject(name: "$name (Lab time)", creditHours: 0, room: '', teacher: teacher); // Updated to show "(Lab time)"

    bool labAdded = false;

    // Look for three consecutive available slots
    for (int i = 0; i < bestTimetable.schedule[0].length; i++) {
      for (int j = 0; j < bestTimetable.schedule.length; j++) {
        int availableSlots = 0; // Count of consecutive available slots
        int firstSlotIndex = -1; // Store the index of the first available slot

        // Check for 3 consecutive free slots
        for (int k = j; k < bestTimetable.schedule.length && availableSlots < 3; k++) {
          if (bestTimetable.schedule[k][i]?.name == dummySubject.name) {
            if (availableSlots == 0) {
              firstSlotIndex = k; // Store the index of the first available slot
            }
            availableSlots++;
          } else {
            break; // Exit if a non-free slot is encountered
          }
        }

        // If 3 consecutive slots found, assign lab
        if (availableSlots == 3) {
          bestTimetable.schedule[firstSlotIndex][i] = labTimeSlot; // Assign lab time slot
          bestTimetable.schedule[firstSlotIndex + 1][i] = labTimeSlot; // Assign second slot
          bestTimetable.schedule[firstSlotIndex + 2][i] = labSubject; // Assign lab subject to the last slot
          labAdded = true;
          break; // Break the loop once lab is added
        }
      }

      if (labAdded) {
        break; // Exit the outer loop if lab was added
      }
    }

    // If no consecutive slots found, show error toast and do not add lab
    if (!labAdded) {
      Fluttertoast.showToast(
        msg: "No available consecutive slots for the lab!", // Show this message if no consecutive slots
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }

    return bestTimetable; // Return the timetable, with no lab added if none found
  }
//////////////// LAB SLOTS ENDS ///////////////

  void _updateSubjectInputFields() {
    setState(() {
      _subjectCount = int.parse(_subjectCountController.text);
      _subjectNameControllers.clear();
      _creditHoursControllers.clear();
      _subjectFormKeys.clear(); // Clear the form keys as well

      // Initialize controllers and form keys for the new subject count
      for (int i = 0; i < _subjectCount; i++) {
        _subjectNameControllers.add(TextEditingController());
        _creditHoursControllers.add(TextEditingController());
        _subjectFormKeys.add(GlobalKey<FormState>()); // Add form key for each subject
      }
    });
  }

// List to keep track of entered subjects
  final List<String> enteredSubjects = [];

  Widget _subjectInputRow(int index, GlobalKey<FormState> subjectFormKey) {
    return Form(
      key: subjectFormKey,
      child: Row(
        children: [
          Text('Subject $index:'),
          const SizedBox(width: 10),
          Expanded(
            child: TextFormField(
              controller: _subjectNameControllers[index - 1],
              decoration: const InputDecoration(labelText: 'Name'),
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a Name';
                } else if (enteredSubjects.contains(value)) {
                  return 'Duplicate entry'; // Show error for duplicate entry
                }
                return null; // No error
              },
              onChanged: (value) {
                // Clear the entered subjects list when editing
                if (enteredSubjects.contains(value)) {
                  enteredSubjects.remove(value);
                }
              },
              onSaved: (value) {
                if (value != null && !enteredSubjects.contains(value)) {
                  enteredSubjects.add(value); // Add the subject to the list if not duplicate
                }
              },
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextFormField(
              controller: _creditHoursControllers[index - 1],
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Credit Hours'),
              validator: (value) {
                int? count = int.tryParse(value!);
                if (value.isEmpty) {
                  return 'Please enter Credit Hours';
                } else if (count == null || count < 1 || count > 3) {
                  return 'Number must be between 1 and 3'; // Updated error message
                }
                return null; // No error
              },
            ),
          ),
        ],
      ),
    );
  }


// _collectSubjectData function to show one available teacher
  void _collectSubjectData() {
    _subjects.clear();
    for (int i = 0; i < _subjectCount; i++) {
      String name = _subjectNameControllers[i].text.trim(); // Trim spaces if any
      int creditHours = int.parse(_creditHoursControllers[i].text);
      String room = _rooms[i % _rooms.length];

      // Get list of teachers for the entered subject
      List<String> teachers = getAvailableTeachersForSubject(name); // Call updated function

      // Filter out already shown teachers
      List<String> availableTeachers = teachers.where((teacher) => !alreadyShownTeachers.contains(teacher)).toList();

      // If there are available teachers, show one, otherwise "No available teacher"
      String teacher;
      if (availableTeachers.isNotEmpty) {
        teacher = availableTeachers.first; // Get the first available teacher
        alreadyShownTeachers.add(teacher); // Track this teacher as shown
      } else {
        teacher = 'No available teacher';
      }
////////////////
      // Adding subject information along with one available teacher
      _subjects.add(Subject(
          name: name, creditHours: creditHours, room: room, teacher: teacher));
    }
  }


  Future<Timetable1> generateTimetables(List<Subject> allSubjects) async {
    // Genetic algorithm ka main function jo timetable generate karta hai
    int populationSize = 100; // Initial population ka size
    int maxGenerations = 100; // Maximum number of generations
    double mutationRate = 0.1; // Mutation rate ka percentage
    int tournamentSize = 3; // Tournament selection ke liye ? parents ko select karna hai
    Timetable1 bestTimetableSoFar = Timetable1(
      List.generate(
        _timeSlots.length,
            (_) => List.generate(_days.length, (_) => null as Subject?), // Initialize as null for Subject?
      ),
      -1,
    ); // Sab se acha timetable track karne ke liye variable

    // Pehle generation ke liye initial population create karte hain
    List<Timetable1> population =
    _initializePopulation(allSubjects, populationSize);

    // Har generation mein process repeat hota hai
    for (int generation = 0; generation < maxGenerations; generation++) {
      // Har timetable ki fitness score evaluate karte hain
      List<int> fitnessScores = _evaluatePopulation(population, allSubjects);

      // Tournament selection algorithm se parents ko select karte hain
      List<Timetable1> selectedParents =
      _tournamentSelection(population, fitnessScores, tournamentSize);

      // Crossover aur mutation se naya offspring create karte hain
      List<Timetable1> offspring = _crossoverAndMutate(selectedParents, mutationRate);

      // Naye offspring ko population mein update karte hain
      population = offspring;

      // Sab se acha timetable update karte hain agar naye population mein improvement ho
      bestTimetableSoFar = _updateBestTimetable(bestTimetableSoFar, population);

      // Last generation par koi additional kaam ho sakta hai
      if (generation == maxGenerations - 1) {}
    }
    // Sab se acha timetable wapas return karte hain
    return bestTimetableSoFar;
  }

// Initial population ko create karne ka function
  List<Timetable1> _initializePopulation(List<Subject> subjects, int size) {
    // Randomly timetable create karte hain population ke size ke mutabiq
    return List.generate(size, (_) => createRandomTimetable(subjects));
  }

// Har timetable ki fitness ko evaluate karne ka function
  List<int> _evaluatePopulation(
      List<Timetable1> population, List<Subject> subjects) {
    // Fitness calculate karte hain har timetable ke liye
    return population
        .map((timetable) => calculateFitness(timetable, subjects))
        .toList();
  }

// Tournament selection ke zariye parents ko select karne ka function
  List<Timetable1> _tournamentSelection(List<Timetable1> population,
      List<int> fitnessScores, int tournamentSize) {
    List<Timetable1> selectedParents = []; // Selected parents ko yahan store karte hain
    for (int i = 0; i < population.length; i++) {
      // Random participants ko tournament ke liye select karte hain
      List<Timetable1> participants = List.generate(tournamentSize,
              (_) => population[Random().nextInt(population.length)]);
      // Total fitness calculate karte hain
      double totalFitness = participants.fold<double>(
          0, (sum, p) => sum + fitnessScores[population.indexOf(p)]);
      // Probability calculate karte hain
      List<double> probabilities = participants
          .map((p) => fitnessScores[population.indexOf(p)] / totalFitness)
          .toList();
      double randomValue = Random().nextDouble(); // Random value generate karte hain
      double cumulativeProb = 0.0; // Cumulative probability ka check
      for (int i = 0; i < tournamentSize; i++) {
        cumulativeProb += probabilities[i];
        if (randomValue <= cumulativeProb) {
          selectedParents.add(participants[i]); // Parent ko select karte hain
          break;
        }
      }
    }
    return selectedParents;
  }

// Crossover aur mutation ka process implement karne ka function
  List<Timetable1> _crossoverAndMutate(
      List<Timetable1> parents, double mutationRate) {
    List<Timetable1> offspring = []; // Naya offspring store karte hain
    for (int i = 0; i < parents.length / 2; i++) {
      // Crossover karke do parents se do children banate hain
      List<Timetable1> children = crossover(parents[2 * i], parents[2 * i + 1]);
      // Children ko mutate karte hain aur offspring mein add karte hain
      offspring.add(mutate(children[0], mutationRate));
      offspring.add(mutate(children[1], mutationRate));
    }
    return offspring;
  }

// Ye function current best timetable ko update karta hai agar naye
// population mein koi aur timetable zyada fitness score rakhta ho
  Timetable1 _updateBestTimetable(
      Timetable1 currentBest, List<Timetable1> population) {
    // Har timetable ko population mein check karte hain
    for (Timetable1 timetable in population) {
      // Agar kisi timetable ka fitness current best se zyada ho
      if (timetable.fitness > currentBest.fitness) {
        // Us timetable ka deep copy le kar usay current best banate hain
        currentBest = timetable.deepCopy();
      }
    }
    // Updated best timetable ko wapas return karte hain
    return currentBest;
  }

  int calculateFitness(Timetable1 timetable, List<Subject> allSubjects) {
    int fitness = 0;

    // Room conflicts
    for (var timeslot in timetable.schedule) {
      Set<String> assignedRooms = {}; // Kisi bhi waqt ke slot mein istemal hone wali rooms ki set
      for (var subject in timeslot) {
        // Agar room pehle se assignedRooms mein hai to conflict ka penalty HO GI
        if (subject?.room != null && assignedRooms.contains(subject!.room)) {
          fitness -= 5; // Room conflict ka penalty: -5 points
        } else if (subject?.room != null) {
          assignedRooms.add(subject!.room!); // Room ko assignedRooms mein add karein
        }
      }
    }

    // Teacher conflicts
    for (var timeslot in timetable.schedule) {
      Set<String> assignedTeachers = {}; // Kisi bhi waqt ke slot mein istemal hone wale teachers ki set
      for (var subject in timeslot) {
        // Agar teacher pehle se assignedTeachers mein hai to conflict ka penalty den
        if (subject?.teacher != null && assignedTeachers.contains(subject!.teacher)) {
          fitness -= 5; // Teacher conflict ka penalty: -5 points
        } else if (subject?.teacher != null) {
          assignedTeachers.add(subject!.teacher!); // Teacher ko assignedTeachers mein add karein
        }
      }
    }

    return fitness;
  }

// Crossover Function - Do timetables ko combine karna
  List<Timetable1> crossover(Timetable1 timetable1, Timetable1 timetable2) {
    // Random cut point generate karte hain jahan se schedule split hota hai
    int cutPoint = Random().nextInt(_timeSlots.length);

    // Pehle offspring ka schedule banate hain, pehle part timetable1 se aur doosra timetable2 se
    List<List<Subject?>> offspring1Schedule =
        timetable1.schedule.sublist(0, cutPoint) +
            timetable2.schedule.sublist(cutPoint);

    // Doosre offspring ka schedule banate hain, pehle part timetable2 se aur doosra timetable1 se
    List<List<Subject?>> offspring2Schedule =
        timetable2.schedule.sublist(0, cutPoint) +
            timetable1.schedule.sublist(cutPoint);

    // Dono offspring wapas return karte hain
    return [
      Timetable1(offspring1Schedule, 0),
      Timetable1(offspring2Schedule, 0)
    ];
  }

// Mutation Function - Timetable mein random changes karne ke liye function
  Timetable1 mutate(Timetable1 timetable, double mutationRate) {
    // Timetable ka deep copy banate hain taake original change na ho
    Timetable1 mutatedTimetable = timetable.deepCopy();

    // Har timeslot aur din ke liye loop chalaate hain
    for (int timeslotIndex = 0; timeslotIndex < _timeSlots.length; timeslotIndex++) {
      // Agar timeslot break time ka hai to usko skip karte hain
      if (_timeSlots[timeslotIndex] == '1PM-2PM') continue;

      for (int dayIndex = 0; dayIndex < _days.length; dayIndex++) {
        // Agar random value mutation rate se kam hoti hai to mutation hota hai
        if (Random().nextDouble() < mutationRate) {
          // Random position select karte hain jahan subject swap hoga
          int pos1Day = Random().nextInt(_days.length - 1);
          int pos1Slot = Random().nextInt(_timeSlots.length - 1);

          // Agar random position break time slot ho to usko skip karte hain
          if (_timeSlots[pos1Slot] == '1PM-2PM') continue;

          // Subjects ko timeslots ke beech swap karte hain
          Subject? temp = mutatedTimetable.schedule[timeslotIndex][dayIndex];
          // Yahan ek single subject ke saath kaam ho raha hai
          mutatedTimetable.schedule[timeslotIndex][dayIndex] = mutatedTimetable.schedule[pos1Slot][pos1Day];
          mutatedTimetable.schedule[pos1Slot][pos1Day] = temp;
        }
      }
    }

    // Mutated timetable wapas return karte hain
    return mutatedTimetable;
  }


// Ye function tournament selection ke zariye parent timetables ko select karta hai
  List<Timetable1> tournamentSelection(
      List<Timetable1> population, List<int> fitnessScores) {
    int tournamentSize = 1; // Tournament ka size set karte hain (kitne participants honge)
    List<Timetable1> selectedParents = []; // Select kiye gaye parents ki list

    // Har individual ko population mein dekhte hain
    for (int i = 0; i < population.length; i++) {
      List<int> participants = []; // Tournament ke participants ki list
      // Jab tak participants ka size tournament size tak na pohonch jaye, loop chalayen
      while (participants.length < tournamentSize) {
        int randomIndex = Random().nextInt(population.length); // Random participant ko select karte hain
        if (!participants.contains(randomIndex)) {
          participants.add(randomIndex); // Usko participant list mein add karte hain
        }
      }
      selectedParents.add(population[participants[fitnessScores.indexOf(fitnessScores[0])]]); // Select karte hain unme se ek ko.
    }

    return selectedParents;
  }

  Timetable1 createRandomTimetable(List<Subject> allSubjects) {
    List<List<Subject?>> schedule = List.generate(
        _timeSlots.length, (_) => List.filled(_days.length, null));
    for (int timeslotIndex = 0;
        timeslotIndex < _timeSlots.length;
        timeslotIndex++) {
      for (int dayIndex = 0; dayIndex < _days.length; dayIndex++) {
        if (_timeSlots[timeslotIndex] != '1PM-2PM') {
          schedule[timeslotIndex][dayIndex] =
              allSubjects[Random().nextInt(allSubjects.length)];
        } else {
          schedule[timeslotIndex][dayIndex] = Subject(
              name: 'Break Time', creditHours: 0, room: '', teacher: '');
        }
      }
    }
    return Timetable1(schedule, 0);
  }


  //////////////same subject ky teacher ko chk kry ga  or single subject ky teacher ko b ///////////
  List<String> alreadyShownTeachers = []; // Track teachers already shown

// Function to get available teachers for a specific subject
  List<String> getAvailableTeachersForSubject(String subject) {
    List<String> availableTeachers = []; // List to hold available teachers
    String trimmedSubject = subject.trim().toLowerCase(); // Trim spaces and convert to lower case
    for (var entry in teacherSubjects.entries) {
      // Check if the teacher teaches the subject
      if (entry.value.any((s) => s.toLowerCase() == trimmedSubject)) {
        availableTeachers.add(entry.key); // Add the teacher to the list
      }
    }
    return availableTeachers; // Return the list of available teachers
  }
}

class Subject {
  String name;
  int creditHours;
  String? room;
  String? teacher;

  Subject(
      {required this.name, required this.creditHours, this.room, this.teacher});
}

class Timetable1 {
  List<List<Subject?>> schedule;
  int fitness;

  Timetable1(this.schedule, this.fitness);

  Timetable1 deepCopy() {
    List<List<Subject?>> newSchedule =
        List.generate(_timeSlots.length, (i) => List.from(schedule[i]));
    return Timetable1(newSchedule, fitness);
  }
}
